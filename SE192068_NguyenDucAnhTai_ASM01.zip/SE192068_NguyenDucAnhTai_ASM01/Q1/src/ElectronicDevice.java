/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author taing
 */
public class ElectronicDevice {
    private int deviceId;
    private String deviceName;
    private double pricePerUnit;
    private int unitsInStock;

    public ElectronicDevice() {
    }

    public ElectronicDevice(int deviceId, String deviceName, double pricePerUnit, int unitsInStock) {
        this.deviceId = deviceId;
        this.deviceName = deviceName;
        this.pricePerUnit = pricePerUnit;
        this.unitsInStock = unitsInStock;
    }

    public int getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(int deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public double getPricePerUnit() {
        return pricePerUnit;
    }

    public void setPricePerUnit(double pricePerUnit) {
        this.pricePerUnit = pricePerUnit;
    }

    public int getUnitsInStock() {
        return unitsInStock;
    }

    public void setUnitsInStock(int unitsInStock) {
        this.unitsInStock = unitsInStock;
    }
    
    public double calculateTotalCost(){
        double totalCost = unitsInStock * pricePerUnit;
        if (totalCost < 100) {
            totalCost *= 0.97; 
        } else if (totalCost <= 200) {
            totalCost *= 0.95; 
        } else if (totalCost <= 500) {
            totalCost *= 0.85; 
        }
        return totalCost;
    }

    @Override
    public String toString() {
        return deviceId + ", " + deviceName + ", " + String.format("%.2f", pricePerUnit) + ", " + unitsInStock + ", " + String.format("%.2f", calculateTotalCost());
    }

    
}
