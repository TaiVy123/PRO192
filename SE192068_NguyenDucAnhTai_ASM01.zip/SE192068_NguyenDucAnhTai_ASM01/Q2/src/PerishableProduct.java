
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author taing
 */
public class PerishableProduct extends Product {

    private int expirationYear;

    public PerishableProduct() {
        super();
        this.expirationYear = 0;
    }
    
    
    public PerishableProduct(String productName, String category, int productionYear, int expirationYear) {
        super(productName, category, productionYear);  
        this.expirationYear = expirationYear;
    }
    public int getExpirationYear() {
        return expirationYear;
    }

    public void setExpirationYear(int expirationYear) {
        this.expirationYear = expirationYear;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getProductionYear() {
        return productionYear;
    }

    public void setProductionYear(int productionYear) {
        this.productionYear = productionYear;
    }

    public String isExpired(int currentYear) {
        return (currentYear > expirationYear) ? "Expired" : "Valid";
    }

    @Override
    public String toString() {
        String productNameFormatted = getProductName().substring(0, 1).toUpperCase() + getProductName().substring(1).toLowerCase();
        String categoryFormatted = getCategory();
        return productNameFormatted + ", " + categoryFormatted + ", " + getProductionYear() + ", " + expirationYear;
    }
}
