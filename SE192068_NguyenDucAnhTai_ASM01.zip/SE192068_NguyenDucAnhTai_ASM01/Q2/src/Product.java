/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author taing
 */
public class Product {
    protected String productName;
    protected String category;
    protected int productionYear;

    public Product() {
    }

    public Product(String productName, String category, int productionYear) {
        this.productName = productName;
        this.category = category;
        this.productionYear = productionYear;
    }

    public String getProductName() {
        return productName;
    }

    public String getCategory() {
         return Character.toUpperCase(category.charAt(0)) + category.substring(1).toLowerCase();
    }

    public int getProductionYear() {
        return productionYear;
    }

    @Override
    public String toString() {
        return productName + ", " + getCategory() + ", " + productionYear;
    }
}
