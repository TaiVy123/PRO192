/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author taing
 */
public class FurnitureList extends ArrayList<Furniture> {

    public void addFurniture(Furniture furniture) {
        this.add(furniture);
    }

    public String getNameById(int id) {
        for (Furniture furniture : this) {
            if (furniture.getId() == id) {
                return furniture.getName();
            }
        }
        return "N/A";
    }

    public FurnitureList getFurnitureList() {
        FurnitureList sortedList = new FurnitureList();
        sortedList.addAll(this);
        sortedList.sort(Comparator.comparingInt(Furniture::getQuantity).reversed());
        return sortedList;
    }

    public int getTotalQuantity() {
        int totalQuantity = 0;
        for (Furniture furniture : this) {
            totalQuantity += furniture.getQuantity();
        }
        return totalQuantity;
    }
}
