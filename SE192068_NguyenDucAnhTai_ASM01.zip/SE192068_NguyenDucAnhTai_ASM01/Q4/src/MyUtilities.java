/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author taing
 */
public class MyUtilities implements IUtilities {

    @Override
    public int sumNumber(int number) {
        int sum = 0;

        for (int i = 1; i <= number / 2; i++) {

            if (number % i == 0) {
                sum += i;
            }
        }
        return sum;
    }

    @Override
    public String replaceString(String sentence, String s1, String s2) {

        String[] words = sentence.split(" ");
        StringBuilder result = new StringBuilder();

        for (String word : words) {

            if (word.equalsIgnoreCase(s1)) {
                result.append(s2);
            } else {
                result.append(word);
            }
            result.append(" ");
        }

        return result.toString().trim();
    }

}
