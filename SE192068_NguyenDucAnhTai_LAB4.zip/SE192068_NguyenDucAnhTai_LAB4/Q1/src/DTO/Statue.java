/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DTO;

import java.util.Scanner;

/**
 *
 * @author taing
 */
public class Statue extends Item {

    private int weight;
    private String colour;

    public Statue() {
    }

    public Statue(int weight, String colour) {
        this.weight = weight;
        this.colour = colour;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public void inputStatue() {
        super.input();
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap weight: ");
        this.weight = sc.nextInt();
        sc = new Scanner(System.in);
        System.out.println("Nhap colour: ");
        this.colour = sc.nextLine();
    }

    public void outputStatue() {
        super.output();
        System.out.println("Weight: " + this.getWeight());
        System.out.println("Colour: " + this.getColour());
    }
}
