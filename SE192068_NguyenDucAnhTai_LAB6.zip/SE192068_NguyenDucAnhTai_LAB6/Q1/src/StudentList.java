/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.ArrayList;

/**
 *
 * @author taing
 */
public class StudentList extends ArrayList<Student> {

    // Default Constructor
    public StudentList() {
        super();
    }

    // Search a student based on student's code. Return the student found
    // This method supports preventing code duplications
    public Student search(String code) {
        code = code.trim().toUpperCase();
        // Linear search is used.
        for (int i = 0; i < this.size(); i++) {
            if (this.get(i).getCode().equals(code)) {
                return this.get(i); // found
            }
        }
        return null; // not found
    }

    // Checking whether a code is duplicated or not
    private boolean isCodeDuplicated(String code) {
        code = code.trim().toUpperCase();
        return search(code) != null;
    }

    // Add new student
    public void addStudent() {
        // Input data of new student
        String newCode, newName;
        int newMark;
        boolean codeDuplicated = false;

        // Pattern: s000 or S000 -> Pattern: "[Ss][\\d]{3}"
        do {
            newCode = Inputter.inputPattern("St. code S000: ", "[Ss][\\d]{3}");
            newCode = newCode.trim().toUpperCase();
            codeDuplicated = isCodeDuplicated(newCode); // check code duplication
            if (codeDuplicated) {
                System.out.println("Code is duplicated!");
            }
        } while (codeDuplicated == true);

        newName = Inputter.inputNonBlankStr("Name of new student: ");
        newName = newName.toUpperCase();
        newMark = Inputter.inputInt("Mark: ", 0, 10); // 0 <= mark <= 10

        // Create new student
        Student st = new Student(newCode, newName, newMark);

        // Add new student to the list
        this.add(st);
        System.out.println("Student " + newCode + " has been added.");
    }

    // Search student based on inputted code
    public void searchStudent() {
        if (this.isEmpty()) {
            System.out.println("Empty list. No search can be performed!");
        } else {
            String code = Inputter.inputStr("Input student code for search: ");
            Student st = this.search(code); // Search student based on code
            if (st == null) {
                System.out.println("Student " + code + " doesn't exist!");
            } else {
                System.out.println(st);
            }
        }
    }

    // Update name and mark based on student's code
    public void updateStudent() {
        if (this.isEmpty()) {
            System.out.println("Empty list. No update can be performed!");
        } else {
            String code = Inputter.inputStr("Input student code for update: ");
            Student st = this.search(code); // Search student
            if (st == null) {
                System.out.println("Student " + code + " doesn't exist!");
            } else {
                String newName = Inputter.inputNonBlankStr("Input new name: ");
                newName = newName.toUpperCase();
                st.setName(newName);
                int newMark = Inputter.inputInt("Input new mark: 0..10", 0, 10);
                st.setMark(newMark);
                System.out.println("Student " + code + " has been updated.");
            }
        }
    }

    // Remove a student based on student's code
    public void removeStudent() {
        if (this.isEmpty()) {
            System.out.println("Empty list. No remove can be performed!");
        } else {
            String code = Inputter.inputStr("Input student code of removed student: ");
            Student st = this.search(code); // Search student
            if (st == null) {
                System.out.println("Student " + code + " doesn't exist!");
            } else {
                this.remove(st); // Remove the student
                System.out.println("Student " + code + " has been removed.");
            }
        }
    }

    // List all students
    public void printAll() {
        if (this.isEmpty()) {
            System.out.println("Empty list!");
        } else {
            System.out.println("Student list:");
            for (Student st : this) {
                System.out.println(st);
            }
            System.out.println("Total: " + this.size() + " student(s).");
        }
    }
}
